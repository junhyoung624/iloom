import React from 'react'
import { motion } from 'framer-motion'

export default function PageTransition({ children }) {
    return (
        <motion.main
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{
                duration: 0.42,
                ease: [0.25, 0.1, 0.25, 1],
            }}
        >
            {children}
        </motion.main>
    )
}